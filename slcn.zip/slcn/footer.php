<?php
$theme_settings = get_posts(array(
    'post_type' => 'theme_settings',
    'name' => 'footer',
    'posts_per_page' => 1,
));

$copyright = '';
$footer_logo = '';
$quick_links = '';
$social = '';

if (!empty($theme_settings) && isset($theme_settings[0])) {
    if (function_exists('get_field')) {
        $copyright = get_field('copyright', $theme_settings[0]->ID);
        $footer_logo = get_field('footer_logo', $theme_settings[0]->ID);
        $quick_links = get_field('quick_links', $theme_settings[0]->ID);
        $social = get_field('social', $theme_settings[0]->ID);
    }
}
?>

<footer>
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
    <script src="main.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
      
    <div class="footer">
        <div class="container footer_section">
            <div class="row">
                <div class="col-md-4 mb-4 align">
                    <div class="Footer_image">
                        <?php if ($footer_logo) : ?>
                            <img src="<?php echo esc_url($footer_logo['url']); ?>" alt="<?php echo esc_attr($footer_logo['alt']); ?>">
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-md-4 mb-4 align">
                    <div class="Quicklinks">
                        <?php echo wp_kses_post($quick_links); ?>
                    </div>
                </div>
                <div class="col-md-4 mb-4 align">
                    <div class="Social">
                        <?php echo wp_kses_post($social); ?>
                    </div>
                </div>
            </div>
        </div>
        <p class="dd"><?php echo esc_html($copyright); ?></p>
    </div>     
</footer>
<script>
    jQuery(document).ready(function($) {
        "use strict";
        //  TESTIMONIALS CAROUSEL HOOK
        $('#customers-testimonials').owlCarousel({
            loop: true,
            center: true,
            items: 3,
            margin: 0,
            autoplay: true,
            dots: true,
            autoplayTimeout: 9500,
            smartSpeed: 450,
            responsive: {
                0: {
                    items: 1
                },
                768: {
                    items: 2
                },
                1170: {
                    items: 3
                }
            }
        });
    });
</script>   
<?php wp_footer(); ?>
</body>
</html>
