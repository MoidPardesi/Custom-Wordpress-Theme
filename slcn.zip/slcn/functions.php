<?php
// This function enqueues the Normalize.css for use. The first parameter is a name for the stylesheet, the second is the URL. Here we
// use an online version of the css file.
function add_normalize_CSS() {
   wp_enqueue_style( 'normalize-styles', "https://cdnjs.cloudflare.com/ajax/libs/normalize/7.0.0/normalize.min.css");
}

add_action('wp_enqueue_scripts', 'add_normalize_CSS');

// Register a new sidebar simply named 'sidebar'
function add_widget_support() {
    register_sidebar( array(
                    'name'          => 'Sidebar',
                    'id'            => 'sidebar',
                    'before_widget' => '<div>',
                    'after_widget'  => '</div>',
                    'before_title'  => '<h2>',
                    'after_title'   => '</h2>',
    ) );
}
// Hook the widget initiation and run our function
add_action( 'widgets_init', 'add_widget_support' );

// Register a new navigation menu
function add_Main_Nav() {
    register_nav_menu('header-menu',__( 'Header Menu' ));
  }
  // Hook to the init action hook, run our navigation menu function
  add_action( 'init', 'add_Main_Nav' );

  function create_theme_settings_cpt() {
    $labels = array(
        'name' => 'Theme Settings',
        'singular_name' => 'Theme Setting',
        'menu_name' => 'Theme Settings',
        'name_admin_bar' => 'Theme Setting',
    );

    $args = array(
        'label' => 'Theme Setting',
        'labels' => $labels,
        'public' => false,
        'show_ui' => true,
        'show_in_menu' => true,
        'capability_type' => 'post',
        'supports' => array('title'),
        'menu_position' => 20,
    );

    register_post_type('theme_settings', $args);
}
add_action('init', 'create_theme_settings_cpt');

function slcn_enqueue_styles() {
    wp_enqueue_style('google-fonts', 'https://fonts.googleapis.com/css?family=Open+Sans:400,700', false);
    wp_enqueue_style('font-awesome', 'https://use.fontawesome.com/releases/v5.7.1/css/all.css', array(), '5.7.1', 'all');
    wp_enqueue_style('bootstrap-css', 'https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css', array(), '5.0.2', 'all');
    wp_enqueue_style('owl-carousel', 'https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css', array(), '2.3.4', 'all');
    wp_enqueue_style('owl-theme', 'https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css', array(), '2.3.4', 'all');
    wp_enqueue_style('main-css', get_template_directory_uri() . '/main.css', array(), '1.0.0', 'all');
}

function slcn_enqueue_scripts() {
    wp_enqueue_script('jquery', 'https://code.jquery.com/jquery-3.6.0.min.js', array(), '3.6.0', true);
    wp_enqueue_script('popper-js', 'https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js', array(), '2.9.3', true);
    wp_enqueue_script('bootstrap-js', 'https://stackpath.bootstrapcdn.com/bootstrap/5.0.2/js/bootstrap.min.js', array(), '5.0.2', true);
    wp_enqueue_script('owl-carousel-js', 'https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js', array(), '2.3.4', true);
}

add_action('wp_enqueue_scripts', 'slcn_enqueue_styles');
add_action('wp_enqueue_scripts', 'slcn_enqueue_scripts');

// Include the TGM_Plugin_Activation class.
require_once get_template_directory() . '/lib/TGM-Plugin-Activation/class-tgm-plugin-activation.php';

add_action('tgmpa_register', 'slcn_register_required_plugins');

function slcn_register_required_plugins() {
    $plugins = array(
        array(
            'name'      => 'Advanced Custom Fields Pro',
            'slug'      => 'advanced-custom-fields-pro',
            'source'    => get_template_directory() . '/lib/plugin/advanced-custom-fields-pro.zip', // Path to the plugin file
            'required'  => true,
        ),
        array(
            'name'      => 'Contact Form 7',
            'slug'      => 'contact-form-7',
            'source'    => get_template_directory() . '/lib/plugin/contact-form-7.zip', // Path to the plugin file
            'required'  => true,
        ),
        // Add other plugins as needed
    );

    $config = array(
        'id'           => 'slcn', // Unique ID for your theme
        'default_path' => '', // Default absolute path to pre-packaged plugins
        'menu'         => 'tgmpa-install-plugins', // Menu slug
        'has_notices'  => true, // Show admin notices or not
        'dismissable'  => false, // If false, a user cannot dismiss the nag message
        'is_automatic' => true, // Automatically activate plugins after installation or not
        'message'      => '', // Message to output right before the plugins table
    );

    tgmpa($plugins, $config);
}

add_action('admin_menu', 'setup_wizard_menu');

function setup_wizard_menu() {
    add_theme_page('Setup Wizard', 'Setup Wizard', 'manage_options', 'setup-wizard', 'setup_wizard_page');
}

function setup_wizard_page() {
    require_once get_template_directory() . '/setup-wizard.php';
}
