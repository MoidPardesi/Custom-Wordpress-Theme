<?php
if (!defined('ABSPATH')) {
    exit;
}

function setup_wizard_content() {
    ob_start(); // Start output buffering
    if (isset($_POST['submit_setup'])) {
        if (!empty($_POST['install_plugins'])) {
            // Trigger the installation and activation of required plugins via TGMPA
            tgmpa_load_bulk_installer();
            $url = add_query_arg(
                array(
                    'page'          => 'tgmpa-install-plugins',
                    'tgmpa-action'  => 'install',
                    'plugins'       => urlencode('advanced-custom-fields-pro,contact-form-7'),
                    'plugin_status' => 'all',
                    '_wpnonce'      => wp_create_nonce('bulk-plugins'),
                ),
                admin_url('themes.php')
            );

            wp_redirect($url);
            ob_end_flush(); // Clean (erase) the output buffer and turn off output buffering
            exit;
        }

        if (!empty($_POST['import_demo_content'])) {
            import_demo_content();
        }

        echo '<div class="updated"><p>Setup complete. Your site is now ready!</p></div>';
    }
    ob_end_flush(); // Clean (erase) the output buffer and turn off output buffering
    ?>

    <div class="wrap">
        <h1>Setup Wizard</h1>
        <form method="post">
            <h2>Step 1: Install Required Plugins</h2>
            <p><input type="checkbox" name="install_plugins" value="yes" checked> Install required plugins</p>

            <h2>Step 2: Import Demo Content</h2>
            <p><input type="checkbox" name="import_demo_content" value="yes" checked> Import demo content</p>

            <p><input type="submit" name="submit_setup" class="button-primary" value="Run Setup"></p>
        </form>
    </div>
    <?php
}

function import_demo_content() {
    $import_file = get_template_directory() . '/demo-content/demo-content.xml';

    if (file_exists($import_file)) {
        require_once ABSPATH . 'wp-admin/includes/import.php';

        if (!class_exists('WP_Import')) {
            include_once ABSPATH . 'wp-content/plugins/wordpress-importer/wordpress-importer.php';
        }

        if (class_exists('WP_Import')) {
            $importer = new WP_Import();
            $importer->fetch_attachments = true;
            $importer->import($import_file);
        } else {
            echo '<div class="error"><p>The WordPress Importer is not installed or activated.</p></div>';
        }
    }
}

setup_wizard_content();
