<?php
/* Template Name: Homepage */
get_header(); ?>

<?php
// Fetching ACF fields
$banner_heading = get_field('banner_heading');
$banner_description = get_field('banner_description');
$primary_button_text = get_field('primary_button_text');
$primary_button_url = get_field('primary_button_url');
$banner_image = get_field('banner_image');
$section_2_heading = get_field('section_2_heading');
$section_2_description = get_field('section_2_description');
$card_title_1 = get_field('card_title_1');
$card_description_1 = get_field('card_description_1');
$card_title_2 = get_field('card_title_2');
$card_description_2 = get_field('card_description_2');
$card_title_3 = get_field('card_title_3');
$card_description_3 = get_field('card_description_3');
$about_us_heading = get_field('about_us_heading');
$about_us_description = get_field('about_us_description');
$about_us_image = get_field('about_us_image');
$accordian_heading = get_field('accordian_heading');
$contact_us_heading = get_field('contact_us_heading');
$contact_us_description = get_field('contact_us_description');
$contact_us_image = get_field('contact_us_image');
$contact_form = get_field('contact_form');
$form_heading = get_field('form_heading');
$testimonial_heading= get_field('testimonial_heading');
?>

<main>
    <section class="banner">
        <div class="banner-content">
            <h1><?php echo esc_html($banner_heading); ?></h1>
            <p><?php echo esc_html($banner_description); ?></p>
            <div class="banner-buttons">
                <a href="<?php echo esc_url($primary_button_url); ?>" class="btn btn-primary"><?php echo esc_html($primary_button_text); ?></a>
            </div>
        </div>
        <div class="banner-image">
            <?php if ($banner_image) : ?>
                <img src="<?php echo esc_url($banner_image['url']); ?>" alt="<?php echo esc_attr($banner_image['alt']); ?>">
            <?php endif; ?>
        </div>
    </section>

    <section class="container mt-5 section2" id="Issues">
        <div class="row">
            <div class="col-12">
                <h2 class="font-weight-bold">
                    <?php echo esc_html($section_2_heading); ?>
                </h2>
                <p class="mt-3">
                    <?php echo esc_html($section_2_description); ?>
                </p>
            </div>
        </div>
    </section>

    <section class="container mt-5 section3">
        <div class="row">
            <div class="col-md-4 mb-4">
                <div class="card card-custom">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo esc_html($card_title_1);?></h5>
                        <p class="card-text"><?php echo esc_html($card_description_1); ?></p>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-4">
                <div class="card card-custom">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo esc_html($card_title_2); ?></h5>
                        <p class="card-text"><?php echo esc_html($card_description_2); ?></p>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-4">
                <div class="card card-custom">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo esc_html($card_title_3); ?></h5>
                        <p class="card-text"><?php echo esc_html($card_description_3); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="banner section4 mt-5" id="aboutus">
        <div class="banner-content">
            <h1><?php echo esc_html($about_us_heading); ?></h1>
            <p><?php echo esc_html($about_us_description); ?></p>
        </div>
        <div class="banner-image">
            <?php if ($about_us_image) : ?>
                <img src="<?php echo esc_url($about_us_image['url']); ?>" alt="<?php echo esc_attr($about_us_image['alt']); ?>">
            <?php endif; ?>
        </div>
    </section>

    <section class="container mt-5 section2" id="speech">
        <div class="row">
            <div class="col-12">
                <h2 class="font-weight-bold">
                    <?php echo esc_html($accordian_heading); ?>
                </h2>
            </div>
        </div>
        <div class="container mt-5">
            <?php if( have_rows('accordion_items') ): ?>
                <div class="accordion" id="accordionExample">
                    <?php
                    $accordion_index = 0;
                    while( have_rows('accordion_items') ) : the_row();
                        $title = get_sub_field('title');
                        $content = get_sub_field('content');
                        $accordion_index++;
                    ?>
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="heading<?php echo $accordion_index; ?>">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse<?php echo $accordion_index; ?>" aria-expanded="false" aria-controls="collapse<?php echo $accordion_index; ?>">
                                    <?php echo esc_html($title); ?>
                                </button>
                            </h2>
                            <div id="collapse<?php echo $accordion_index; ?>" class="accordion-collapse collapse" aria-labelledby="heading<?php echo $accordion_index; ?>" data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    <?php echo wp_kses_post($content); ?>
                                </div>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>
            <?php endif; ?>
        </div>
    </section>
    
    <section class="banner section6 mt-5">
        <div class="banner-content">
            <h1><?php echo esc_html($contact_us_heading); ?></h1>
            <p><?php echo esc_html($contact_us_description); ?></p>
        </div>
        <div class="banner-image">
            <?php if ($contact_us_image) : ?>
                <img src="<?php echo esc_url($contact_us_image['url']); ?>" alt="<?php echo esc_attr($contact_us_image['alt']); ?>">
            <?php endif; ?>
        </div>
    </section>

    <section class="container mt-5 section2" id="reviews">
        <div class="row">
            <div class="col-12">
                <h2 class="font-weight-bold">
                    <?php echo esc_html($testimonial_heading); ?>
                </h2>
            </div>
        </div>
    </section>

    <!-- TESTIMONIALS -->
    <section class="testimonials">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <div id="customers-testimonials" class="owl-carousel">
                        <?php if( have_rows('testimonials') ): ?>
                            <?php while( have_rows('testimonials') ): the_row(); 
                                $image = get_sub_field('t_image');
                                $content = get_sub_field('content_t');
                                $author = get_sub_field('author');
                            ?>
                            <div class="item">
                                <div class="shadow-effect">
                                    <img class="img-circle" src="<?php echo esc_url($image['url']); ?>" alt="<?php echo esc_attr($image['alt']); ?>">
                                    <p><?php echo esc_html($content); ?></p>
                                </div>
                                <div class="testimonial-name"><?php echo esc_html($author); ?></div>
                            </div>
                            <?php endwhile; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- END OF TESTIMONIALS -->

    <section class="container mt-5 section2" id="contact">
        <div class="row">
            <div class="col-12">
                <h2 class="font-weight-bold">
                    <?php echo esc_html($form_heading); ?>
                </h2>
            </div>
        </div>
        <div class="contact_form">
            <?php echo do_shortcode($contact_form); ?>
        </div>
    </section>
</main>

<?php get_footer(); ?>
